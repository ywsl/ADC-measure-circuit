#include "stm32f10x.h"                  // Device header
#include "AD.H"


//led��ʼ������
void LED_Init(void)
{
	//����һ���ṹ��
	GPIO_InitTypeDef GPIO_InitStructure;
	//ʹ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_8 | GPIO_Pin_9);	//��λ���ص�
}

//���ƺ���
void LED8_ON(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);

}	

void LED9_ON(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_9);
}	
/////////////////////////////////////////////////////////////////////////////

//�صƺ���
void LED8_OFF(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
}	

void LED9_OFF(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_9);
}	


///////////////////////////////////////////////////////////////////////////

/*void LED1_Turn()																				//��ת����
{
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_1)==0)				//��ȡ��ǰ�˿����״̬
	{
		 LED1_OFF();										
	}
	else 
	{
		 LED1_ON();
	}
}

void LED2_Turn()																				//��ת����
{
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_2)==0)
	{
		LED2_OFF();
	}
	else 
	{
		LED2_ON();
	}
}
*/

void LED_ADC_Control()
{	
	uint16_t light;
	
	
	//	LED8_OFF();
	//	LED9_OFF();
		light = AD_GetValue(ADC_Channel_1);;
		if(light>2400)					//���ȵ���2400ʱPA9����
		{
			LED9_ON();
			LED8_ON();
		} else if(light>1800)		//���ȵ���1800ʱPA8����
			{
			LED8_ON();
			LED9_OFF();
			}else if(light<1400)	//���ȵ���1400ʱ��ȫ��
				{
					LED8_OFF();
					LED9_OFF();
				}
}
	

























