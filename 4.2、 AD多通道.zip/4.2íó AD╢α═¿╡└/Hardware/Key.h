#ifndef _Key_H
#define _Key_H
#define uint8_t unsigned char

void Key_Init(void);
uint8_t Key_GetNum(void);






#endif













